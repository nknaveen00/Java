package com.mycompany.atmsystem;

import java.util.Scanner;


public class ATM {

    public static void main(String args[]) {
        // TODO code application logic here
        Main main=new Main("Naveen","NAVE2000");
        main.Menu();
    }
}

class Main{
    String custname;
    String custID;
    int balance;
    int lastTransaction;
    int cr_dt=0;
    public Main(String name,String ID){
        custname=name;
        custID=ID;
    }
    
    public void Menu(){
        int option;
        Scanner scan=new Scanner(System.in);
        System.out.println("###################################################");
        System.out.println("###\tWelcome to ATM System "+custname+"\t\t###");
        System.out.println("###\tYour customer ID "+custID+"\t\t###");
        System.out.println("###################################################");
        System.out.println("\n");
        System.out.println("1. Check Balance");
        System.out.println("2. Deposit");
        System.out.println("3. Withdraw");
        System.out.println("4. Last Transaction");
        System.out.println("5. Cancel");
        System.out.println("Enter your option");
        option=scan.nextInt();
        do{
            switch(option){
                case 1: Checkbalance();
                        break;
                case 2: deposit();
                        break;
                case 3: withdraw();
                        break;
                case 4: lastransactions();
                        break;
                case 5: System.exit(0);
            }
            System.out.println("Enter your option");
            option=scan.nextInt();
        }while(option>0 && option<=5);
    }
    public void Checkbalance(){
        System.out.println("\n");
        System.out.println("``````````````````````````````````````````````````");
        System.out.println("\t\t"+custname+" Your balance is  "+balance);
        System.out.println("``````````````````````````````````````````````````");
        System.out.println("\n");
    }
    public void deposit(){
        int amount;
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter the amount to deposite");
        amount= scan.nextInt();
        if(amount!=0){
            balance=balance+amount;
            lastTransaction=amount;
            cr_dt=1;
            System.out.println("Amount deposited successfully");
        }
        else{
            System.out.println("Couldn't deposite 0 balance");
        }
        System.out.println("\n");
    }
    
    public void withdraw(){
        int amount;
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter the amount to withdraw");
        amount=scan.nextInt();
        if(amount>0){
            if(balance>=amount){
                balance=balance-amount;
                lastTransaction=amount;
                cr_dt=2;
                System.out.println("Amount drawed successfully");
            }
            else{
                System.out.println("Insufficient balance");
            }
        }
        else{
            System.out.println("Enter amount above 0");
        }
        System.out.println("\n");
    }
    
    public void lastransactions(){
        if(cr_dt==1){
            System.out.println("The Last Transaction "+lastTransaction+" /Cr");
        }
        else if(cr_dt==2){
            System.out.println("The Last Transaction "+lastTransaction+" /Dt");
        }
        else{
            System.out.println("There no Transaction");
        }
        System.out.println("\n");
    }
}