package TicketBooking;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Random;

public class Booking {
    String[] name=new String[63];
    int[] Age=new int[63];
    char[] gender=new char[63];
    char[] ub=new char[21];
    char[] lb=new char[21];
    char[] mb=new char[21];
    int[] ticketId=new int[63];
    int[] pnr=new int[63];
    int startUB=0;
    int ubindex=0;
    int insertub=0;
    int startMB=21;
    int mbindex=21;
    int insertmb=0;
    int startLB=42;
    int lbindex=42;
    int insertlb=0;
    int end=62;
    int ractktId[]=new int[18];
    int racindex=0;
    ArrayList<Integer> wlticktId=new ArrayList<>(10);
    int wlindex=0;
    int confirm=0;
   
    public Booking(){
        Arrays.fill(name, "-");
        Arrays.fill(Age, 0);
        Arrays.fill(gender, '-');
        Arrays.fill(ub, '-');
        Arrays.fill(mb, '-');
        Arrays.fill(lb, '-');
        Arrays.fill(ticketId, 0);
        Arrays.fill(pnr, 0);
        Arrays.fill(ractktId, 0);
    }
    
    public void checkseat(){
        int avail=0,booked=0;
        int i,j,k;
        System.out.println("------------------------------------------------------------------------------------");
        System.out.println("|TicketID   |Upper Berth  |TicketID   |Middle Berth   |TicketID    |Lower Berth    |");
        System.out.println("------------------------------------------------------------------------------------");
        for(i=startUB,j=startMB,k=startLB;i<21;i++,j++,k++)
            System.out.println("|"+ticketId[i]+"      |"+ub[i]+"           |"+ticketId[j]+"       |"+mb[i]+"             |"+ticketId[k]+"       |"+lb[i]+"\t\t  |");
        System.out.println("------------------------------------------------------------------------------------");
        System.out.println("\n");
        for(i=startUB;i<startMB;i++){
            if(ticketId[i]==0)
                avail++;
            else
                booked++;
        }
        System.out.println("Available "+avail+" 'UPPER' berths"+"\t\t"+"Booked "+booked+" 'UPPER' berths");
        avail=0;
        booked=0;
        for(j=startMB;j<startLB;j++){
            if(ticketId[j]==0)
                avail++;
            else
                booked++;
        }
        System.out.println("Available "+avail+" 'MIDDLE' berths"+"\t\t"+"Booked "+booked+" 'MIDDLE' berths");
        avail=0;
        booked=0;
        for(k=startLB;k<=end;k++){
            if(ticketId[k]==0)
                avail++;
            else
                booked++;
        }
        System.out.println("Available "+avail+" 'LOWER' berths"+"\t\t"+"Booked "+booked+" 'LOWER' berths");
    }
    
    public void bookgeneral(){ 
        int i=1;
        String names;
        char sex,berth;
        int ages,tkt,Pnr;
        Scanner scan=new Scanner(System.in);
        if(insertub<startMB||insertub<startLB||insertlb<=end){
            System.out.println("Enter how many tickets you want");
            int n=scan.nextInt();
            while(i<=n){
                System.out.println("Enter your 'NAME' ");
                names=scan.next();
                System.out.println("Enter your 'AGE' ");
                ages=scan.nextInt();
                System.out.println("Enter your 'GENDER' (M/F/T)");
                sex=scan.next().charAt(0);
                label:System.out.println("Enter your 'BERTH' (U/M/L)");
                berth=scan.next().charAt(0);
                System.out.println("Are you sure entered details are correct (Yes: 1/ NO: 0)");
                confirm=scan.nextInt();
                if(confirm==1){
                    Random rand=new Random();
                    tkt=rand.nextInt(10000);
                    Pnr=rand.nextInt(1000000);
                    switch (berth) {
                        case 'U':
                            if(insertub<startMB){
                                name[ubindex]=names;
                                Age[ubindex]=ages;
                                gender[ubindex]=sex;
                                ub[insertub]=berth;
                                ticketId[ubindex]=tkt;
                                pnr[ubindex]=Pnr;
                                System.out.println("Ticket booked successfully");
                                System.out.println("Your 'PNR NO' "+pnr[ubindex]);
                                System.out.println("Your 'TICKETID' "+ticketId[ubindex]);
                                ubindex++;
                                insertub++;
                            }else{
                                System.out.println("Upper Berth Full");
                                bookgeneral();
                            }
                            break;
                        case 'M':
                            if(insertmb<startLB){
                                name[mbindex]=names;
                                Age[mbindex]=ages;
                                gender[mbindex]=sex;
                                mb[insertmb]=berth;
                                ticketId[mbindex]=tkt;
                                pnr[mbindex]=Pnr;
                                System.out.println("Ticket booked successfully");
                                System.out.println("Your 'PNR NO' "+pnr[mbindex]);
                                System.out.println("Your 'TICKETID' "+ticketId[mbindex]);
                                mbindex++;
                                insertmb++;
                            }else{
                                System.out.println("Middle Berth Full");
                                bookgeneral();
                            }
                            break;
                        case 'L':
                            if(insertlb<=end){
                                name[lbindex]=names;
                                Age[lbindex]=ages;
                                gender[lbindex]=sex;
                                lb[insertlb]=berth;
                                ticketId[lbindex]=tkt;
                                pnr[lbindex]=Pnr;
                                System.out.println("Ticket booked successfully");
                                System.out.println("Your 'PNR NO' "+pnr[lbindex]);
                                System.out.println("Your 'TICKETID' "+ticketId[lbindex]);
                                lbindex++;
                                insertlb++;
                            }else{
                                System.out.println("Lower Berth Full");
                                bookgeneral();
                            }
                            break;
                        default:
                            System.out.println("Enter valid berth!!!");
                            bookgeneral();
                            break;
                    }
                }else{
                    System.out.println("Enter details again");
                    bookgeneral();
                }
                i++;
            }   
        }
        else if(racindex<18||wlindex<10){
            System.out.println("There is only RAC Tickets\nAre you book RAC ticket (Yes: 1/No:0)");
            confirm=scan.nextInt();
            if(confirm==1)
                racbooking();
            else
                System.out.println("Thank you!");    
        }
        else if(racindex<18||wlindex<10){
            System.out.println("If you book you'll go under Waiting List Tickets\nAre you book RAC ticket (Yes: 1/No:0)");
            if(wlindex<10){
            confirm=scan.nextInt();
            if(confirm==1)
                wlbooking();
            else
                System.out.println("Thank you!");
            }
        }
        else{
            System.out.println("Ticket not available\nSorry for this trouble");
        }
    }
    
    public void ractickets(){
        int booked=0,avail=0;
        System.out.println("------------------------------");
        System.out.println("|     Tickets     |");
        System.out.println("------------------------------");
        for(int i=0;i<18;i++){
            if(ractktId[i]!=0){
                System.out.println("|"+ractktId[i]+"           "+"|Booked      |");
                booked++;
            }else{
                System.out.println("|0              "+"|Not Booked  |");
                avail++;
            }
        }
        System.out.println("------------------------------");
        System.out.println("\nBooked 'RAC' tickets: "+booked+"\nAvailable 'RAC' tickets: "+avail);
    }
    
    public void racbooking(){
        Random rand=new Random();
        ractktId[racindex]=rand.nextInt(10000);
        racindex++;
        System.out.println("Ticket booked successfully in 'RAC LIST'");
    }
    
    public void wltickets(){
        System.out.println("------------------------------");
        System.out.println("|TicketId       |Tickets     |");
        System.out.println("------------------------------");
        for(int i=0;i<wlticktId.size();i++){
            System.out.println("|"+wlticktId.get(i)+"           "+"|Booked      |");
        }
        for(int i=0;i<10;i++){
            System.out.println("|0             "+"|Not Booked  |");
        }
        System.out.println("------------------------------");
        System.out.println("\nBooked 'RAC' tickets: "+wlindex+"\nAvailable 'RAC' tickets: "+(9-wlindex));
    }
    
    public void wlbooking(){
        Random random=new Random();
        wlticktId.add(random.nextInt(10000));
        wlindex++;
        System.out.println("Ticket booked successfully in 'WAITING LIST'");
    }
    
    public void cancelticket(){
        int tktId,i;
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter your TicketId");
        tktId=scan.nextInt();
        System.out.println("Are you confirm cancelling the ticket");
        confirm=scan.nextInt();
        if(confirm==1){
            if(!(wlticktId.isEmpty())){
                for(i=0;i<63;i++){
                    if(ticketId[i]==tktId)
                        break;
                }
                if(i<21){
                   ticketId[i]=wlticktId.get(0);
                   name[i]="xxxx";
                   wlticktId.remove(0);
                   wlindex--;
                   System.out.println("Ticket cancelled successfully");
                }else if(i>20&&i<42){
                    ticketId[i]=wlticktId.get(0);
                    name[i]="xxxx";
                    wlticktId.remove(0);
                    wlindex--;
                    System.out.println("Ticket cancelled successfully");
                }else if(i>=42&&i<63){
                    ticketId[i]=wlticktId.get(0);
                    name[i]="xxxx";
                    wlticktId.remove(0);
                    wlindex--;
                    System.out.println("Ticket cancelled successfully");
                }else{
                    System.out.println("Enter correct TicketID");
                }
            }
            else{
                for(i=0;i<63;i++){
                    if(ticketId[i]==tktId)
                        break;
                }
                if(i<21){
                   ticketId[i]=0;
                   name[i]="-";
                   Age[i]=0;
                   gender[i]='-';
                   pnr[i]=0;
                   ub[i]='-';
                   //ubindex--;
                   //insertub--;
                   System.out.println("Ticket cancelled successfully");
                }else if(i>=21&&i<42){
                   ticketId[i]=0;
                   name[i]="-";
                   Age[i]=0;
                   gender[i]='-';
                   pnr[i]=0;
                   mb[i-21]='-';
                   //mbindex--;
                   //insertmb--;
                   System.out.println("Ticket cancelled successfully");
                }else if(i>=42&&i<=62){
                   ticketId[i]=0;
                   name[i]="-";
                   Age[i]=0;
                   gender[i]='-';
                   pnr[i]=0;
                   lb[i-42]='-';
                   //lbindex--;
                   //insertlb--;
                   System.out.println("Ticket cancelled successfully");
                }else{
                    System.out.println("Enter correct TicketID");
                }
            }
        }
    }
    
    public void printdetails(){
        int tktId,i;
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter your 'TICKET ID'");
        tktId=scan.nextInt();
        for(i=0;i<63;i++){
            if(ticketId[i]==tktId)
                break;
        }
        if(i<21){
            System.out.println("---------------------------------------------------------------------------");
            System.out.println("|TicketId    |PNR No    |Name               |Age     |Gender    |Berth    |");
            System.out.println("---------------------------------------------------------------------------");
            System.out.println("|"+ticketId[i]+"          "+pnr[i]+"     "+name[i]+"             "+Age[i]+"           "+gender[i]+"            "+ub[i]+"      |");
            System.out.println("---------------------------------------------------------------------------");
        }else if(i>=21&&i<42){
            System.out.println("---------------------------------------------------------------------------");
            System.out.println("|TicketId    |PNR No    |Name               |Age     |Gender    |Berth    |");
            System.out.println("---------------------------------------------------------------------------");
            System.out.println("|"+ticketId[i]+"          "+pnr[i]+"     "+name[i]+"             "+Age[i]+"           "+gender[i]+"            "+mb[i-21]+"      |");
            System.out.println("---------------------------------------------------------------------------");
        }else if(i>=42&&i<=62){
            System.out.println("---------------------------------------------------------------------------");
            System.out.println("|TicketId    |PNR No    |Name               |Age     |Gender    |Berth    |");
            System.out.println("---------------------------------------------------------------------------");
            System.out.println("|"+ticketId[i]+"          "+pnr[i]+"     "+name[i]+"             "+Age[i]+"           "+gender[i]+"            "+lb[i-42]+"      |");
            System.out.println("---------------------------------------------------------------------------");
        }
        else{
            System.out.println("The 'TICKET ID' is not available");
        }
    }
}
