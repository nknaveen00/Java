package TicketBooking;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Random;

public class Booking1 {
    String[] name=new String[63];
    int[] Age=new int[63];
    char[] gender=new char[63];
    char[] ub=new char[21];
    char[] lb=new char[21];
    char[] mb=new char[21];
    int[] ticketId=new int[63];
    int[] pnr=new int[63];
    int startUB=0;
    int ubindex=0;
    int insertub=0;
    int startMB=21;
    int mbindex=21;
    int insertmb=0;
    int startLB=42;
    int lbindex=42;
    int insertlb=0;
    int end=63;
    int ractktId[]=new int[18];
    int racindex=0;
    ArrayList<Integer> wlticktId=new ArrayList<>(10);
    int wlindex=0;
    
    public Booking1(){
        Arrays.fill(name, "-");
        Arrays.fill(Age, 0);
        Arrays.fill(gender, '-');
        Arrays.fill(ub, '-');
        Arrays.fill(mb, '-');
        Arrays.fill(lb, '-');
        Arrays.fill(ticketId, 0);
        Arrays.fill(pnr, 0);
        Arrays.fill(ractktId, 0);
    }
    
    public void checkseat(){
        int avail=0,booked=0;
        int i,j,k;
        System.out.println("------------------------------------------------------------------------------------");
        System.out.println("|TicketID   |Upper Berth  |TicketID   |Middle Berth   |TicketID    |Lower Berth    |");
        System.out.println("------------------------------------------------------------------------------------");
        for(i=startUB,j=startMB,k=startLB;i<21;i++,j++,k++)
            System.out.println("|"+ticketId[i]+"      |"+ub[i]+"           |"+ticketId[j]+"       |"+mb[i]+"             |"+ticketId[k]+"       |"+lb[i]+"\t\t  |");
        System.out.println("------------------------------------------------------------------------------------");
        System.out.println("\n");
        for(i=startUB;i<startMB;i++){
            if(ticketId[i]==0)
                avail++;
            else
                booked++;
        }
        System.out.println("Available "+avail+" 'UPPER' berths"+"\t\t"+"Booked "+booked+" 'UPPER' berths");
        avail=0;
        booked=0;
        for(j=startMB;j<startLB;j++){
            if(ticketId[j]==0)
                avail++;
            else
                booked++;
        }
        System.out.println("Available "+avail+" 'MIDDLE' berths"+"\t\t"+"Booked "+booked+" 'MIDDLE' berths");
        avail=0;
        booked=0;
        for(k=startLB;k<end;k++){
            if(ticketId[k]==0)
                avail++;
            else
                booked++;
        }
        System.out.println("Available "+avail+" 'LOWER' berths"+"\t\t"+"Booked "+booked+" 'LOWER' berths");
    }
    
    public void bookgeneral(){
        Scanner scan=new Scanner(System.in);
        Random rand=new Random();
        if(insertub<20||insertmb<20||insertlb<20){
            for(int i=0;i<63;i++){
                System.out.println(i);
                System.out.println("Enter name");
                name[i]="naveen";
                System.out.println("Enter age");
                Age[i]=23;
                System.out.println("Enter gender");
                gender[i]='M';
                ticketId[i]=rand.nextInt(10000);
                pnr[i]=rand.nextInt(1000000);
            }
            for(int i=0;i<=20;i++){
                ub[i]='U';
                lb[i]='L';
                mb[i]='M';
            }
            insertub=20;
            insertlb=20;
            insertmb=20;
            ubindex=21;
            mbindex=42;
            lbindex=63;
        }
        else if(racindex<18){
            racbooking();
        }
        else if(wlindex<10){
            wlbooking();
        }
        else{
            System.out.println("Ticket Not Available");
        }
    }
    
    public void ractickets(){
        int booked=0,avail=0;
        System.out.println("------------------------------");
        System.out.println("|TicketId       |Tickets     |");
        System.out.println("------------------------------");
        for(int i=0;i<18;i++){
            if(ractktId[i]!=0){
                System.out.println("|"+ractktId[i]+"           "+"|Booked      |");
                booked++;
            }else{
                System.out.println("|0              "+"|Not Booked  |");
                avail++;
            }
        }
        System.out.println("------------------------------");
        System.out.println("\nBooked 'RAC' tickets: "+booked+"\nAvailable 'RAC' tickets: "+avail);
    }
    
    public void racbooking(){
        Random rand=new Random();
        for(int i=0;i<18;i++){
            ractktId[i]=rand.nextInt(10000);
            racindex++;
        }
        System.out.println("Ticket booked successfully in 'RAC LIST'");
    }
    
    public void wltickets(){
        System.out.println("------------------------------");
        System.out.println("|TicketId       |Tickets     |");
        System.out.println("------------------------------");
        for(int i=0;i<wlticktId.size();i++){
            System.out.println("|"+wlticktId.get(i)+"           "+"|Booked      |");
        }
        for(int i=wlticktId.size();i<10;i++){
            System.out.println("|0              "+"|Not Booked  |");
        }
        System.out.println("------------------------------");
        System.out.println("\nBooked 'WAITING LIST' tickets: "+wlindex+"\nAvailable 'WAITING LIST' tickets: "+(10-wlindex));
    }
    
    public void wlbooking(){
        Random random=new Random();
        for(int i=0;i<10;i++){
            wlticktId.add(random.nextInt(10000));
            wlindex++;
        }
        System.out.println("Ticket booked successfully in 'WAITING LIST'");
    }
    
    public void cancelticket(){
        int tktId,i,confirm;
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter your TicketId");
        tktId=scan.nextInt();
        System.out.println("Are you confirm cancelling the ticket");
        confirm=scan.nextInt();
        if(confirm==1){
            if(!(wlticktId.isEmpty())){
                for(i=0;i<63;i++){
                    if(ticketId[i]==tktId)
                        break;
                }
                if(i<21){
                   ticketId[i]=wlticktId.get(0);
                   name[i]="xxxx";
                   wlticktId.remove(0);
                   wlindex--;
                   System.out.println("Ticket cancelled successfully");
                }else if(i>20&&i<42){
                    ticketId[i]=wlticktId.get(0);
                    name[i]="xxxx";
                    wlticktId.remove(0);
                    wlindex--;
                    System.out.println("Ticket cancelled successfully");
                }else if(i>=42&&i<63){
                    ticketId[i]=wlticktId.get(0);
                    name[i]="xxxx";
                    wlticktId.remove(0);
                    wlindex--;
                    System.out.println("Ticket cancelled successfully");
                }else{
                    System.out.println("Enter correct TicketID");
                }
            }
            else{
                for(i=0;i<63;i++){
                    if(ticketId[i]==tktId)
                        break;
                }
                if(i<21){
                   ticketId[i]=0;
                   name[i]="-";
                   Age[i]=0;
                   gender[i]='-';
                   pnr[i]=0;
                   ub[i]='-';
                   //ubindex--;
                   //insertub--;
                   System.out.println("Ticket cancelled successfully");
                }else if(i>=21&&i<42){
                   ticketId[i]=0;
                   name[i]="-";
                   Age[i]=0;
                   gender[i]='-';
                   pnr[i]=0;
                   mb[i-21]='-';
                   //mbindex--;
                   //insertmb--;
                   System.out.println("Ticket cancelled successfully");
                }else if(i>=42&&i<=62){
                   ticketId[i]=0;
                   name[i]="-";
                   Age[i]=0;
                   gender[i]='-';
                   pnr[i]=0;
                   lb[i-42]='-';
                   //lbindex--;
                   //insertlb--;
                   System.out.println("Ticket cancelled successfully");
                }else{
                    System.out.println("Enter correct TicketID");
                }
            }
        }
    }
    
    public void printdetails(){
        int tktId,i;
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter your 'TICKET ID'");
        tktId=scan.nextInt();
        for(i=0;i<63;i++){
            if(ticketId[i]==tktId)
                break;
        }
        if(i<21){
            System.out.println("---------------------------------------------------------------------------");
            System.out.println("|TicketId    |PNR No    |Name               |Age     |Gender    |Berth    |");
            System.out.println("---------------------------------------------------------------------------");
            System.out.println("|"+ticketId[i]+"          "+pnr[i]+"     "+name[i]+"             "+Age[i]+"           "+gender[i]+"            "+ub[i]+"      |");
            System.out.println("---------------------------------------------------------------------------");
        }else if(i>=21&&i<42){
            System.out.println("---------------------------------------------------------------------------");
            System.out.println("|TicketId    |PNR No    |Name               |Age     |Gender    |Berth    |");
            System.out.println("---------------------------------------------------------------------------");
            System.out.println("|"+ticketId[i]+"          "+pnr[i]+"     "+name[i]+"             "+Age[i]+"           "+gender[i]+"            "+mb[i-21]+"      |");
            System.out.println("---------------------------------------------------------------------------");
        }else if(i>=42&&i<=62){
            System.out.println("---------------------------------------------------------------------------");
            System.out.println("|TicketId    |PNR No    |Name               |Age     |Gender    |Berth    |");
            System.out.println("---------------------------------------------------------------------------");
            System.out.println("|"+ticketId[i]+"          "+pnr[i]+"     "+name[i]+"             "+Age[i]+"           "+gender[i]+"            "+lb[i-42]+"      |");
            System.out.println("---------------------------------------------------------------------------");
        }
        else{
            System.out.println("The 'TICKET ID' is not available");
        }
    }
}
