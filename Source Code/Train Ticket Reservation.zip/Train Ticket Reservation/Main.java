package com.mycompany.railway;


//import TicketBooking.Booking;
import TicketBooking.Booking1;
import java.util.Scanner;


public class Main {

    public static void main(String args[]) {
        // TODO code application logic here
        System.out.println("\t--- Welcome to Ultra Fast King Express Reservation ---");
        System.out.println("\t\t--- Train no: 1728 ---");
        int ch;
        Scanner scan=new Scanner(System.in);
        //Booking book=new Booking();
        Booking1 book=new Booking1();
        do{
            System.out.println("\n1. Check Seats");
            System.out.println("2. Book Ticket");
            System.out.println("3. RAC Tickets");
            System.out.println("4. Wainting List");
            System.out.println("5. Cancel Ticket");
            System.out.println("6. Print Details");
            System.out.println("7. Exit");
            System.out.println("Enter your choice");
            ch=scan.nextInt();
            switch(ch){
                case 1: book.checkseat();
                        break;
                case 2: book.bookgeneral();
                        break;
                case 3: book.ractickets();
                        break;
                case 4: book.wltickets();
                        break;
                case 5: book.cancelticket();
                        break;
                case 6: book.printdetails();
                        break;
                case 7: System.exit(0);
            }
        }while(ch>0 && ch<=7);
    }
}
